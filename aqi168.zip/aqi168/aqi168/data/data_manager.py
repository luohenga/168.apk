# -*- coding: utf-8 -*-
import json
import os
import time

from kivy.clock import mainthread
from kivy.logger import Logger

from aqi168.aqi import overall_aqi, fill_iaqi
from aqi168.data.sources import (
    CNEMCRealtimeSource,
    PublicAggregatorSource,
    MockSource,
    make_snapshot_from_items,
)
from aqi168.i18n import tr


class DataManager:
    """管理数据源、刷新间隔与降级链。"""

    DEFAULT_INTERVAL = 10  # 分钟

    def __init__(self, city_store):
        self.city_store = city_store
        self.refresh_interval_min = self.DEFAULT_INTERVAL
        self._source_key = "cnemc"
        self._sources = {
            "cnemc": CNEMCRealtimeSource(),
            "public": PublicAggregatorSource(),
            "mock": MockSource(city_store),
        }
        self._active = self._sources["cnemc"]
        self._current_token = 0

    # ---------- 配置 ----------
    def set_source(self, key):
        if key in self._sources:
            self._source_key = key
            self._active = self._sources[key]
            Logger.info("AQI168: source -> %s", key)

    def set_public_token(self, token):
        self._sources["public"].set_token(token)

    def available_sources(self):
        return [("cnemc", tr("source_cnemc")),
                ("public", tr("source_public")),
                ("mock", tr("source_mock"))]

    def current_source_key(self):
        return self._source_key

    # ---------- 拉取 ----------
    def fetch_all(self, on_success, on_error, force_source=None):
        """
        拉取数据并管理降级链：
        主源(cnemc/public) 失败 -> 本地演示源(mock) 兜底。
        mock 不依赖网络，保证任何情况下 App 都有可展示数据。
        """
        token = self._current_token + 1
        self._current_token = token
        primary = self._sources.get(force_source, self._active)
        primary_key = getattr(primary, "key", "cnemc")

        def _primary_done(snapshot, source_key):
            if token != self._current_token:
                return
            self.city_store._snapshot_source = source_key
            self.save_snapshot(snapshot, source_key)
            on_success(self.city_store.build_ranked_list(), snapshot, source_key)

        def _primary_fail(msg):
            if token != self._current_token:
                return
            Logger.warning("AQI168: primary source %s failed: %s, fallback to mock",
                           primary_key, msg)
            # 主源失败 -> 用 mock 兜底，确保界面始终有数据
            self._run_mock(token, on_success, on_error,
                           fallback_msg="%s 不可用: %s" % (primary_key, msg))

        try:
            primary.fetch(self.city_store, _primary_done, _primary_fail,
                          token=token, manager=self)
        except Exception as e:  # noqa
            _primary_fail(str(e))

    def _run_mock(self, token, on_success, on_error, fallback_msg=""):
        """运行 mock 兜底源。"""
        mock = self._sources.get("mock")
        if mock is None:
            on_error(fallback_msg or "无可用数据源")
            return

        def _done(snapshot, source_key):
            if token != self._current_token:
                return
            self.city_store._snapshot_source = source_key
            self.save_snapshot(snapshot, source_key)
            on_success(self.city_store.build_ranked_list(), snapshot, source_key)

        def _fail(msg):
            if token != self._current_token:
                return
            on_error("%s；兜底源也失败: %s" % (fallback_msg, msg))

        try:
            mock.fetch(self.city_store, _done, _fail, token=token, manager=None)
        except Exception as e:  # noqa
            _fail(str(e))

    def save_snapshot(self, snapshot, source_key):
        """把成功拉到的数据序列化到本地缓存，断网时可回放。"""
        try:
            path = os.path.join(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))), "cache")
            if not os.path.isdir(path):
                os.makedirs(path)
            payload = {
                "ts": int(time.time()),
                "source": source_key,
                "data": {str(k): v for k, v in snapshot.items()},
            }
            with open(os.path.join(path, "snapshot.json"), "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
        except Exception as e:  # noqa
            Logger.warning("AQI168: cache save failed: %s", e)

    def load_cached_snapshot(self):
        path = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "cache", "snapshot.json")
        if not os.path.isfile(path):
            return None, 0, ""
        try:
            d = json.load(open(path, encoding="utf-8"))
            return d.get("data", {}), d.get("ts", 0), d.get("source", "")
        except Exception:  # noqa
            return None, 0, ""



