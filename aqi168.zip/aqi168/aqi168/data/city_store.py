# -*- coding: utf-8 -*-
import json
import os
import time
from datetime import datetime

from kivy.logger import Logger

from aqi168.aqi import calc_aqi, aqi_level, aqi_color
from aqi168.i18n import tr

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 打包后数据文件在包目录内，开发时在上一级目录
_PKG = os.path.dirname(os.path.abspath(__file__))


def _resolve(name):
    for base in (_BASE, _PKG, os.getcwd()):
        p = os.path.join(base, name)
        if os.path.isfile(p):
            return p
    return os.path.join(_BASE, name)


def _num(v):
    if v is None or v == "":
        return None
    if isinstance(v, str) and v.lower() in ("nan", "none", "null"):
        return None
    try:
        return float(v)
    except Exception:
        return None


def _load_cities():
    return json.load(open(_resolve("cities.json"), encoding="utf-8"))


def _load_breaks():
    return json.load(open(_resolve("aqi_breakpoints.json"), encoding="utf-8"))


class City:
    __slots__ = ("id", "name", "region", "province", "timezone",
                 "aqi", "pm25", "pm10", "so2", "no2", "o3", "co",
                 "primary", "level", "color", "station_time", "rank", "history")

    def __init__(self, raw):
        self.id = raw["id"]
        self.name = raw["name"]
        self.region = raw["region"]
        self.province = raw["province"]
        self.timezone = raw.get("timezone", "Asia/Shanghai")
        self.aqi = None
        self.pm25 = self.pm10 = self.so2 = self.no2 = self.o3 = self.co = None
        self.primary = "—"
        self.level = "—"
        self.color = "#9E9E9E"
        self.station_time = None
        self.rank = 0
        self.history = []  # [(ts, aqi)]

    def update_from_dict(self, d):
        try:
            self.aqi = _num(d.get("aqi"))
        except Exception:
            self.aqi = None
        self.pm25 = _num(d.get("pm25"))
        self.pm10 = _num(d.get("pm10"))
        self.so2 = _num(d.get("so2"))
        self.no2 = _num(d.get("no2"))
        self.o3 = _num(d.get("o3"))
        self.co = _num(d.get("co"))
        self.station_time = d.get("time") or d.get("station_time")
        self.primary = (d.get("primary") or d.get("primary_pollutant") or "—")
        if isinstance(self.primary, str) and self.primary in ("nan", "", "None", "null"):
            self.primary = "—"
        self._recalc()

    def update_from_iaqi(self, iaqi, time_str=None):
        """用分项 IAQI 字典更新：iaqi 含 pm25/pm10/so2/no2/o3/co 的分指数。"""
        self.pm25 = _num(iaqi.get("pm25"))
        self.pm10 = _num(iaqi.get("pm10"))
        self.so2 = _num(iaqi.get("so2"))
        self.no2 = _num(iaqi.get("no2"))
        self.o3 = _num(iaqi.get("o3"))
        self.co = _num(iaqi.get("co"))
        self.primary = iaqi.get("primary") or "—"
        self.station_time = time_str or iaqi.get("time")
        vals = {k: v for k, v in iaqi.items() if k in ("pm25", "pm10", "so2", "no2", "o3", "co") and _num(v) is not None}
        if vals:
            self.aqi = max(vals.values())
        else:
            self.aqi = None
        self._recalc()

    def _recalc(self):
        self.level = aqi_level(self.aqi)
        self.color = aqi_color(self.aqi)

    def push_history(self, ts=None, maxlen=48):
        if self.aqi is None:
            return
        ts = ts or int(time.time())
        if self.history and self.history[-1][0] == ts:
            self.history[-1] = (ts, self.aqi)
        else:
            self.history.append((ts, self.aqi))
        if len(self.history) > maxlen:
            self.history = self.history[-maxlen:]

    def concentration(self, key):
        return getattr(self, key, None)


class CityStore:
    def __init__(self):
        self._by_id = {c["id"]: City(c) for c in _load_cities()}
        self._breaks = _load_breaks()
        self._snapshot_ts = 0
        self._snapshot_source = ""

    def all_cities(self):
        return list(self._by_id.values())

    def get(self, city_id):
        return self._by_id.get(city_id)

    def count(self):
        return len(self._by_id)

    def set_snapshot(self, snapshot, source_key=""):
        """snapshot: {city_id: dict}，必须包含 aqi 或 iaqi。"""
        self._snapshot_ts = int(time.time())
        self._snapshot_source = source_key
        for cid, data in snapshot.items():
            # 兼容字符串/整数 key
            try:
                city = self._by_id.get(int(cid))
            except (ValueError, TypeError):
                city = self._by_id.get(cid)
            if not city:
                continue
            if "iaqi" in data and data["iaqi"]:
                city.update_from_iaqi(data["iaqi"], data.get("time"))
            else:
                city.update_from_dict(data)
            city.push_history(self._snapshot_ts)
        self._recompute_ranks()

    def get_last_snapshot(self):
        return {c.id: c for c in self._by_id.values() if c.aqi is not None}

    def build_ranked_list(self):
        valid = [c for c in self._by_id.values() if c.aqi is not None]
        valid.sort(key=lambda c: (c.aqi, c.id))
        for i, c in enumerate(valid, 1):
            c.rank = i
        return valid

    def _recompute_ranks(self):
        self.build_ranked_list()

    def format_time(self):
        if not self._snapshot_ts:
            return "—"
        return datetime.fromtimestamp(self._snapshot_ts).strftime("%Y-%m-%d %H:%M")

    def active_source_label(self):
        key = self._snapshot_source
        return tr("current_source", name=tr("source_" + key)) if key else ""

    def recalc_from_breaks(self, concentrations, primary=None):
        """给定实测浓度 dict（μg/m³，CO 为 mg/m³），按 HJ 633-2012 自洽计算 AQI。"""
        out = {}
        for k, v in concentrations.items():
            key = k.upper()
            if key in self._breaks and v is not None:
                out[key] = calc_aqi(v, self._breaks[key])
        return out
