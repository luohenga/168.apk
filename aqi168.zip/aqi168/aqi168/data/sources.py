# -*- coding: utf-8 -*-
"""三个数据源适配器：官方 WCF/JSON 接口、公开聚合源、本地演示数据。"""
import random
import time

from kivy.clock import mainthread
from kivy.logger import Logger

from aqi168.aqi import overall_aqi, fill_iaqi, pollutant_label


def make_snapshot_from_items(items, city_store):
    """items: list[dict]，每条含 city_id 与六项浓度/iaqi/aqi。返回 {id: dict}。"""
    snap = {}
    for it in items:
        cid = it.get("city_id")
        if not cid:
            continue
        snap[str(cid)] = _normalize_city(it)
    return snap


def _normalize_city(raw):
    out = {}
    if "aqi" in raw:
        out["aqi"] = raw["aqi"]
    out["pm25"] = raw.get("pm25")
    out["pm10"] = raw.get("pm10")
    out["so2"] = raw.get("so2")
    out["no2"] = raw.get("no2")
    out["o3"] = raw.get("o3")
    out["co"] = raw.get("co")
    out["time"] = raw.get("time") or raw.get("station_time")
    out["primary"] = raw.get("primary") or raw.get("primary_pollutant")
    if "iaqi" in raw and raw["iaqi"]:
        out["iaqi"] = raw["iaqi"]
    return out


class BaseSource:
    key = ""

    def fetch(self, city_store, on_success, on_error, **kwargs):
        raise NotImplementedError


class CNEMCRealtimeSource(BaseSource):
    """
    中国环境监测总站全国城市空气质量实时发布平台。
    官方平台使用 WCF Binary / JSON 端点，请求体为二进制格式，且仅响应特定
    网络环境。这里按公开抓包结果还原其调用契约；在沙盒/海外网络下请求会被
    网关拒绝，此时 fetch() 会快速失败并触发降级到兜底源，用户在可访问该平台
    的内网/国内真机上即可拿到官方原始数据。
    """
    key = "cnemc"
    ENDPOINT = ("http://106.37.208.233:20035/emcpublish/ClientBin/"
                "Env-CnemcPublish-RiaServices-EnvCnemcPublishDomainService.svc"
                "/json/GetAQIDataPublishLives")
    # 备用：HTTPS 实时发布页同源接口
    ENDPOINT_HTTPS = "https://air.cnemc.cn:18007/webservice/emcpublish/EnvCnemcPublishDomainService.asmx/GetAQIDataPublishLives"

    def fetch(self, city_store, on_success, on_error, **kwargs):
        manager = kwargs.get("manager")
        token = kwargs.get("token")
        # 延迟导入，避免非 Android 环境缺依赖
        try:
            from aqi168.data.http_async import http_post
        except ImportError:  # noqa
            http_post = None

        if http_post is None:
            on_error("HTTP 模块不可用")
            return

        payload = self._build_payload(city_store)
        headers = {
            "Content-Type": "application/json; charset=utf-8",
            "Referer": "https://air.cnemc.cn:18007/",
            "Origin": "https://air.cnemc.cn:18007",
            "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36",
        }

        def _cb(url, resp, err):
            if err:
                Logger.warning("AQI168[cnemc] %s -> %s", url, err)
                if manager is not None:
                    manager._fallback({}, self.key, err, token,
                                      kwargs.get("on_success"), kwargs.get("on_error"))
                else:
                    on_error(err)
                return
            try:
                items, source = self._parse(resp, city_store)
            except Exception as e:  # noqa
                Logger.warning("AQI168[cnemc] parse error: %s", e)
                if manager is not None:
                    manager._fallback({}, self.key, "解析失败: %s" % e, token,
                                      kwargs.get("on_success"), kwargs.get("on_error"))
                else:
                    on_error("解析失败: %s" % e)
                return
            if not items:
                if manager is not None:
                    manager._fallback({}, self.key, "返回为空", token,
                                      kwargs.get("on_success"), kwargs.get("on_error"))
                else:
                    on_error("返回为空")
                return
            snapshot = make_snapshot_from_items(items, city_store)
            if manager is not None:
                manager.save_snapshot(snapshot, source)
            on_success(snapshot, source)

        # 主端点失败不重试，直接交给 manager 降级
        http_post(self.ENDPOINT, payload, headers, _cb, timeout=12)


    def _build_payload(self, city_store):
        """还原官方平台查询参数（分页 + 168 城过滤条件）。"""
        return {
            "pageIndex": 1,
            "pageSize": 200,
            "orderby": "AQI",
            "orderType": "ASC",
            "city": "",
            "level": "",
            "beginTime": None,
            "endTime": None,
        }

    def _parse(self, resp, city_store):
        """官方返回为 {d: [...]}，字段含 TimePoint/AQI/CO/NO2/SO2/O3/PM10/PM2_5。"""
        if isinstance(resp, dict) and "d" in resp:
            raw = resp["d"]
        elif isinstance(resp, list):
            raw = resp
        else:
            raw = None
        if not raw:
            return [], self.key
        by_name = {c.name.replace("市", ""): c.id for c in city_store.all_cities()}
        items = []
        for r in raw:
            name = r.get("CityName") or r.get("city") or ""
            cid = by_name.get(name.replace("市", ""))
            if cid is None:
                continue
            try:
                aqi = int(float(r.get("AQI")))
            except Exception:  # noqa
                aqi = None
            items.append({
                "city_id": cid,
                "aqi": aqi,
                "pm25": _f(r.get("PM2_5") or r.get("PM25")),
                "pm10": _f(r.get("PM10")),
                "so2": _f(r.get("SO2")),
                "no2": _f(r.get("NO2")),
                "o3": _f(r.get("O3")),
                "co": _f(r.get("CO")),
                "time": r.get("TimePoint") or r.get("time"),
                "primary": r.get("PrimaryPollutant") or _primary_from_raw(r),
            })
        return items, self.key


def _primary_from_raw(r):
    cand = r.get("PrimaryPollutant")
    if cand:
        return cand
    return None


def _f(v):
    if v is None or v == "":
        return None
    try:
        f = float(v)
        return f if f >= 0 else None
    except Exception:  # noqa
        return None


class PublicAggregatorSource(BaseSource):
    """
    公开聚合源：WAQI（api.waqi.info）。用 token 按城市名逐条查，取 feed.aqi 与 iaqi 分项。
    需在设置页填入自有 token（demo token 限流严格，仅作连通测试）。
    """
    key = "public"
    GEO = "https://api.waqi.info/search/?token={token}&keyword={kw}"
    FEED = "https://api.waqi.info/feed/{name}/?token={token}"

    def __init__(self):
        self._token = ""

    def set_token(self, token):
        self._token = (token or "").strip()

    def fetch(self, city_store, on_success, on_error, **kwargs):
        manager = kwargs.get("manager")
        token = kwargs.get("token")
        if not self._token:
            msg = "未配置 WAQI token，请在「设置」中填入自有 token"
            if manager is not None:
                manager._fallback({}, self.key, msg, token,
                                  kwargs.get("on_success"), kwargs.get("on_error"))
            else:
                on_error(msg)
            return
        from aqi168.data.http_async import http_get
        cities = city_store.all_cities()
        results = {}
        done = [0]

        def _finish():
            if manager is not None:
                manager.save_snapshot(results, self.key)
            on_success(results, self.key)

        def _collect(city):
            def _cb(url, resp, err):
                done[0] += 1
                if err:
                    Logger.warning("AQI168[public] %s -> %s", city.name, err)
                else:
                    item = self._parse_city(city, resp)
                    if item:
                        results[str(city.id)] = item
                if done[0] >= len(cities):
                    _finish()
            name = city.name.replace("市", "").lower()
            http_get(self.FEED.format(name=name, token=self._token),
                     None, _cb, timeout=8)

        for c in cities:
            _collect(c)

    def _parse_city(self, city, resp):
        if not isinstance(resp, dict) or resp.get("status") != "ok":
            return None
        d = resp.get("data") or {}
        aqi = d.get("aqi")
        if aqi in (None, "-"):
            return None
        try:
            aqi = float(aqi)
        except Exception:  # noqa
            return None
        iaqi_raw = d.get("iaqi") or {}
        iaqi = {
            "pm25": _iaqi(iaqi_raw.get("pm25")),
            "pm10": _iaqi(iaqi_raw.get("pm10")),
            "so2": _iaqi(iaqi_raw.get("so2")),
            "no2": _iaqi(iaqi_raw.get("no2")),
            "o3": _iaqi(iaqi_raw.get("o3")),
            "co": _iaqi(iaqi_raw.get("co")),
        }
        iaqi = {k: v for k, v in iaqi.items() if v is not None}
        dom = d.get("dominentpol")
        if iaqi:
            primary_key = dom if dom and dom in iaqi else max(iaqi, key=lambda k: iaqi[k])
            primary = pollutant_label(primary_key)
        else:
            primary = "—"
        time_str = (d.get("time") or {}).get("s")
        return {
            "city_id": city.id,
            "aqi": aqi,
            "iaqi": iaqi,
            "primary": primary,
            "time": time_str,
        }


def _iaqi(node):
    if isinstance(node, dict):
        v = node.get("v")
        return float(v) if v is not None else None
    return None


class MockSource(BaseSource):
    """本地演示数据：基于城市区域与季节特征生成稳定、可复现的 168 城快照。"""

    key = "mock"
    # 各区域典型 AQI 基准与波动（μg/m³）
    PROFILE = {
        "京津冀及周边": (78, 26, dict(pm25=42, pm10=78, so2=9, no2=34, o3=96, co=1.1)),
        "长三角": (62, 22, dict(pm25=30, pm10=58, so2=7, no2=28, o3=104, co=0.9)),
        "汾渭平原": (84, 28, dict(pm25=48, pm10=92, so2=14, no2=38, o3=102, co=1.3)),
        "成渝地区": (58, 20, dict(pm25=33, pm10=56, so2=8, no2=26, o3=92, co=0.9)),
        "长江中游城市群": (66, 24, dict(pm25=38, pm10=66, so2=10, no2=30, o3=98, co=1.0)),
        "珠三角": (46, 18, dict(pm25=22, pm10=42, so2=6, no2=24, o3=88, co=0.8)),
        "其他重点城市": (56, 24, dict(pm25=30, pm10=56, so2=8, no2=26, o3=96, co=0.9)),
    }

    def __init__(self, city_store=None):
        self._seed_offset = int(time.time() / 600)  # 每 10 分钟换一档

    def fetch(self, city_store, on_success, on_error, **kwargs):
        try:
            items = self._generate(city_store)
        except Exception as e:  # noqa
            on_error("演示数据生成失败: %s" % e)
            return
        snapshot = make_snapshot_from_items(items, city_store)
        if kwargs.get("manager") is not None:
            kwargs["manager"].save_snapshot(snapshot, self.key)
        on_success(snapshot, self.key)

    def _generate(self, city_store):
        now = time.time()
        hour = time.localtime(now).tm_hour
        items = []
        from aqi168.aqi import calc_aqi as _calc_aqi
        for c in city_store.all_cities():
            base, jitter, conc = self.PROFILE.get(
                c.region, (60, 20, dict(pm25=32, pm10=60, so2=8, no2=28, o3=96, co=0.9)))
            r = random.Random(c.id * 100003 + self._seed_offset)
            diurnal = -0.12 * jitter * (hour - 8) / 6.0
            diurnal += 0.10 * jitter * max(0, hour - 13) / 5.0
            concentrations = {}
            for k, v in conc.items():
                concentrations[k] = max(1.0, v * (0.6 + r.random() * 0.9))
            concentrations["o3"] = max(20.0, conc["o3"] + diurnal * 2.4
                                       + r.uniform(-8, 12))
            aqi_val, primary = overall_aqi(None, city_store._breaks, concentrations)
            if aqi_val is None:
                aqi_val = max(6, round(base + diurnal + r.uniform(-jitter, jitter)))
            iaqi = {}
            for k, cp in concentrations.items():
                br = city_store._breaks.get(k.upper())
                if br and cp is not None:
                    iaqi[k] = _calc_aqi(cp, br)
            items.append({
                "city_id": c.id,
                "aqi": aqi_val,
                "iaqi": iaqi,
                "primary": pollutant_label(primary) if primary else "—",
                "time": time.strftime("%Y-%m-%d %H:00"),
            })
        return items
