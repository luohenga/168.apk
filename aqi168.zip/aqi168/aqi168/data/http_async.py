# -*- coding: utf-8 -*-
"""
异步 HTTP 请求：把网络调用放到线程池，回调切回主线程。
不依赖任何 Android 专有库，桌面/Android 通用。
"""
import json

from kivy.clock import mainthread
from kivy.logger import Logger

try:
    from urllib.request import Request, urlopen
    from urllib.error import URLError, HTTPError
    import ssl
    URLLIB_OK = True
except Exception:  # noqa
    URLLIB_OK = False

try:
    from concurrent.futures import ThreadPoolExecutor
    _EXECUTOR = ThreadPoolExecutor(max_workers=4)
except Exception:  # noqa
    _EXECUTOR = None


def _make_context():
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:  # noqa
        return None


def _decode(body):
    for enc in ("utf-8", "gbk", "gb18030", "latin-1"):
        try:
            return body.decode(enc)
        except Exception:  # noqa
            continue
    return body.decode("utf-8", "replace")


def _request(url, data=None, headers=None, timeout=10):
    headers = dict(headers or {})
    headers.setdefault("User-Agent", "AQI168App/1.0")
    req = Request(url, data=data, headers=headers, method="POST" if data else "GET")
    ctx = _make_context()
    with urlopen(req, timeout=timeout, context=ctx) as r:
        raw = r.read()
        ctype = r.headers.get("Content-Type", "")
    text = _decode(raw)
    if "application/json" in ctype or text.strip().startswith(("{", "[")):
        try:
            return json.loads(text)
        except Exception:  # noqa
            return text
    return text


def _worker(url, data, headers, timeout, callback):
    err = None
    resp = None
    try:
        resp = _request(url, data=data, headers=headers, timeout=timeout)
    except HTTPError as e:  # noqa
        try:
            detail = _decode(e.read())
        except Exception:  # noqa
            detail = ""
        err = "HTTP %s %s" % (e.code, detail[:80])
    except URLError as e:  # noqa
        err = "网络不可达: %s" % e.reason
    except Exception as e:  # noqa
        err = "%s" % e
    if callback:
        callback(url, resp, err)


@mainthread
def _dispatch(url, resp, err, callback):
    try:
        callback(url, resp, err)
    except Exception as e:  # noqa
        Logger.warning("AQI168: http callback error: %s", e)


def http_post(url, payload, headers=None, callback=None, timeout=10):
    if not URLLIB_OK or _EXECUTOR is None:
        if callback:
            callback(url, None, "HTTP 不可用")
        return
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    hdr = dict(headers or {})
    hdr.setdefault("Content-Type", "application/json; charset=utf-8")

    def _run():
        _worker(url, body, hdr, timeout,
                lambda u, r, e: _dispatch(u, r, e, callback))

    _EXECUTOR.submit(_run)


def http_get(url, headers=None, callback=None, timeout=10):
    if not URLLIB_OK or _EXECUTOR is None:
        if callback:
            callback(url, None, "HTTP 不可用")
        return

    def _run():
        _worker(url, None, headers, timeout,
                lambda u, r, e: _dispatch(u, r, e, callback))

    _EXECUTOR.submit(_run)
