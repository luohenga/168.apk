# -*- coding: utf-8 -*-
"""多语言文本。默认简体中文，预留英文字典即可扩展。"""

STRINGS = {
    "zh": {
        "app_title": "168城空气质量实时排名",
        "ranking": "实时排名",
        "trend": "24小时趋势",
        "refresh": "刷新",
        "settings": "设置",
        "back": "返回",
        "search_hint": "搜索城市 / 省份",
        "all_regions": "全部区域",
        "sort_by_aqi": "按AQI排名",
        "sort_by_pm25": "按PM2.5",
        "sort_by_change": "按升降位",
        "rank": "排名",
        "city": "城市",
        "aqi": "AQI",
        "level": "等级",
        "primary": "首要污染物",
        "update_time": "更新时间",
        "updated_at": "更新于 {time}",
        "loading": "正在获取最新监测数据…",
        "offline": "无网络，暂无数据",
        "using_cached": "接口异常，显示缓存快照",
        "fetch_failed": "数据获取失败：{msg}",
        "fetch_failed_cached": "接口异常：{msg}，已切换缓存",
        "no_result": "没有匹配的城市",
        "select_source": "数据源",
        "source_cnemc": "官方实时（环境监测总站）",
        "source_public": "公开聚合源（WAQI token）",
        "source_mock": "本地演示数据（断网可用）",
        "current_source": "当前源：{name}",
        "auto_refresh": "自动刷新",
        "refresh_interval": "刷新间隔",
        "minutes": "分钟",
        "pollutants": "污染物浓度（μg/m³）",
        "note_official": "官方接口需在内网/国内网络访问，数据未经终审，仅供实时动态参考。",
        "note_caveat": "说明",
        "caveat_text": "实时AQI仅反映当前时次，不等于生态环境部月度累计综合指数排名。",
        "change_up": "上升{val}位",
        "change_down": "下降{val}位",
        "change_none": "持平",
        "trend_title": "近24个时次趋势",
        "trend_now": "最新值 {val}",
        "detail_about": "关于本应用",
        "detail_about_text": "数据以中国环境监测总站全国城市空气质量实时发布平台为优先源，"
                            "辅以公开聚合接口与本地演示数据兜底。168城名单依据生态环境部"
                            "《城市环境空气质量排名技术规定》及月度报告附表整理。",
    },
    "en": {
        "app_title": "168 City AQI Live Ranking",
        "ranking": "Live Ranking",
        "trend": "24h Trend",
        "refresh": "Refresh",
        "settings": "Settings",
        "back": "Back",
        "search_hint": "Search city / province",
        "all_regions": "All regions",
        "sort_by_aqi": "Sort by AQI",
        "sort_by_pm25": "Sort by PM2.5",
        "sort_by_change": "Sort by rank change",
        "rank": "Rank",
        "city": "City",
        "aqi": "AQI",
        "level": "Level",
        "primary": "Primary pollutant",
        "update_time": "Updated",
        "updated_at": "Updated {time}",
        "loading": "Fetching latest monitoring data…",
        "offline": "Offline, no data",
        "using_cached": "Source error, showing cached snapshot",
        "fetch_failed": "Fetch failed: {msg}",
        "fetch_failed_cached": "Source error: {msg}, cached data shown",
        "no_result": "No matching city",
        "select_source": "Data source",
        "source_cnemc": "Official (CNEMC realtime)",
        "source_public": "Public aggregator (WAQI token)",
        "source_mock": "Local demo data (offline)",
        "current_source": "Source: {name}",
        "auto_refresh": "Auto refresh",
        "refresh_interval": "Refresh interval",
        "minutes": "min",
        "pollutants": "Pollutant concentration (μg/m³)",
        "note_official": "Official feed requires domestic network; data is preliminary, for realtime reference only.",
        "note_caveat": "Note",
        "caveat_text": "Realtime AQI is not the same as monthly cumulative composite index ranking.",
        "change_up": "Up {val}",
        "change_down": "Down {val}",
        "change_none": "—",
        "trend_title": "Last 24 hours",
        "trend_now": "Latest {val}",
        "detail_about": "About",
        "detail_about_text": "Priority source is CNEMC realtime platform, with public aggregator and local demo fallback. "
                            "The 168-city list follows MEE's technical regulation and monthly report annex.",
    },
}

_LANG = "zh"


def set_language(lang):
    global _LANG
    if lang in STRINGS:
        _LANG = lang


def tr(key, **kwargs):
    s = STRINGS.get(_LANG, STRINGS["zh"]).get(key)
    if s is None:
        s = STRINGS["zh"].get(key, key)
    return s.format(**kwargs) if kwargs else s
