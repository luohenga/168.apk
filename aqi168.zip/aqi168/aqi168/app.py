# -*- coding: utf-8 -*-
"""168 重点城市空气质量实时排名 App"""
import os
os.environ.setdefault("KIVY_NO_ARGS", "1")

from kivy.app import App
from kivy.clock import Clock
from kivy.logger import Logger
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.spinner import Spinner
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse, Line
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
from kivy.properties import StringProperty, BooleanProperty, ListProperty, NumericProperty

from aqi168.i18n import tr
from aqi168.data.city_store import CityStore
from aqi168.data.data_manager import DataManager
from aqi168.ui.rank_screen import RankScreen
from aqi168.ui.detail_screen import DetailScreen
from aqi168.ui.settings_screen import SettingsScreen


class AQI168App(App):
    title = "168城空气质量实时排名"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.city_store = CityStore()
        self.data_manager = DataManager(self.city_store)
        self._refresh_event = None

    def build(self):
        self.sm = ScreenManager()
        self.rank_screen = RankScreen(
            app_ref=self,
            on_city_select=self._on_city_select,
            on_refresh=self._manual_refresh,
            on_settings=self._open_settings,
            on_toggle_auto=self._toggle_auto_refresh,
        )
        screen = Screen(name="rank")
        screen.add_widget(self.rank_screen)
        self.sm.add_widget(screen)

        self.detail_screen = DetailScreen(app_ref=self, on_back=self._back_to_rank)
        ds = Screen(name="detail")
        ds.add_widget(self.detail_screen)
        self.sm.add_widget(ds)

        self.settings_screen = SettingsScreen(
            app_ref=self, on_back=self._back_to_rank,
            on_source_change=self._on_source_change,
            on_interval_change=self._on_interval_change,
        )
        ss = Screen(name="settings")
        ss.add_widget(self.settings_screen)
        self.sm.add_widget(ss)

        return self.sm

    def on_start(self):
        Clock.schedule_once(lambda dt: self._manual_refresh(show_loading=True), 0.3)
        self._apply_interval(self.data_manager.refresh_interval_min)

    def on_stop(self):
        self._cancel_refresh()

    def _apply_interval(self, minutes):
        self._cancel_refresh()
        if minutes > 0:
            self._refresh_event = Clock.schedule_interval(
                lambda dt: self._manual_refresh(), max(1, int(minutes * 60)))

    def _cancel_refresh(self):
        if self._refresh_event:
            self._refresh_event.cancel()
            self._refresh_event = None

    def _toggle_auto_refresh(self, enabled):
        if enabled:
            self._apply_interval(self.data_manager.refresh_interval_min)
        else:
            self._cancel_refresh()

    def _manual_refresh(self, *args, **kwargs):
        show_loading = kwargs.get("show_loading", False)
        self.rank_screen.set_loading(show_loading)
        self.data_manager.fetch_all(
            on_success=lambda items, snapshot, source_key: self._on_data_ready(
                items, snapshot, source_key),
            on_error=lambda msg: self._on_fetch_error(msg),
        )

    def _on_data_ready(self, items, snapshot, source_key):
        self.rank_screen.set_loading(False)
        prev = {c.id: c for c in self.city_store.get_last_snapshot().values()
                if c.rank} if self.city_store.get_last_snapshot() else {}
        self.city_store.set_snapshot(snapshot, source_key)
        self.rank_screen.show_ranking(items, prev)
        self.rank_screen.set_status(tr("updated_at", time=self.city_store.format_time()))
        self.rank_screen.set_source(self.city_store.active_source_label())
        # 更新详情页
        if self.sm.current == "detail":
            self.detail_screen.update_chart(self.city_store, self.data_manager)

    def _on_fetch_error(self, msg):
        self.rank_screen.set_loading(False)
        cached = self.city_store.get_last_snapshot()
        if cached:
            items = self.city_store.build_ranked_list()
            self.rank_screen.show_ranking(items, {})
            self.rank_screen.set_status(tr("using_cached"))
            self._toast(tr("fetch_failed_cached", msg=msg))
        else:
            self.rank_screen.set_status(tr("offline"))
            self._toast(tr("fetch_failed", msg=msg))

    def _on_city_select(self, city_id):
        self.detail_screen.bind_city(city_id, self.city_store, self.data_manager)
        self.sm.current = "detail"

    def _back_to_rank(self, *args):
        self.sm.current = "rank"

    def _open_settings(self):
        self.settings_screen.refresh(self.data_manager)
        self.sm.current = "settings"

    def _on_source_change(self, source_key):
        self.data_manager.set_source(source_key)
        self._manual_refresh()

    def _on_interval_change(self, minutes):
        self.data_manager.refresh_interval_min = minutes
        self._apply_interval(minutes)

    def _toast(self, text):
        """简易提示条。"""
        from kivy.uix.popup import Popup
        try:
            popup = Popup(title="", content=Label(text=text, color=(1, 1, 1, 1)),
                          size_hint=(0.7, 0.15), auto_dismiss=True,
                          background_color=(0.2, 0.6, 0.6, 0.9))
            popup.open()
            Clock.schedule_once(lambda dt: popup.dismiss(), 2.5)
        except Exception:
            Logger.warning("AQI168: toast failed: %s", text)
