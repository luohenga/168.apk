# -*- coding: utf-8 -*-
"""AQI 分指数计算（HJ 633-2012）与等级、颜色、首要污染物判定。"""


def calc_iaqi(cp, bp_lo, bp_hi, iaqi_lo, iaqi_hi):
    if cp is None:
        return None
    if bp_hi == bp_lo:
        return iaqi_hi
    return (iaqi_hi - iaqi_lo) / (bp_hi - bp_lo) * (cp - bp_lo) + iaqi_lo


def calc_aqi(concentration, breaks):
    """breaks: [(iaqi_lo, iaqi_hi, cp_lo, cp_hi), ...] 已按浓度升序。"""
    if concentration is None:
        return None
    cp = float(concentration)
    for iaqi_lo, iaqi_hi, bp_lo, bp_hi in breaks:
        if bp_lo <= cp <= bp_hi:
            v = calc_iaqi(cp, bp_lo, bp_hi, iaqi_lo, iaqi_hi)
            return round(v, 1) if v is not None else None
    return breaks[-1][1]  # 超出最高段取上限


def overall_aqi(iaqi_dict, breaks_map, concentrations):
    """由六项浓度计算各分指数，返回 (AQI, 首要污染物键)。"""
    res = {}
    for key, cp in concentrations.items():
        br = breaks_map.get(key)
        if br and cp is not None:
            res[key] = calc_aqi(cp, br)
    if not res:
        return None, None
    primary = max(res, key=lambda k: res[k])
    return round(res[primary], 0), primary


# 浓度段中点值（仅在缺失分项时用于估计各分项分指数，保证六项趋势图能画出来）
_FILL_HINT = {
    "PM25": (30, 50),
    "PM10": (45, 80),
    "SO2": (6, 10),
    "NO2": (15, 28),
    "O3": (90, 140),
    "CO": (0.6, 1.1),
}


def fill_iaqi(aqi, breaks_map):
    """按 AQI 数值反推六项分指数区间（估测，仅用于无分项时的演示兜底）。"""
    if aqi is None:
        return {}
    out = {}
    for key, br in breaks_map.items():
        # 找 AQI 所在段，取该段浓度中点的分指数作为示意
        lo, hi = _FILL_HINT.get(key, (None, None))
        if lo is None:
            continue
        cp = (lo + hi) / 2.0
        out[key] = calc_aqi(cp, br)
    # 保证最大值为 aqi 本身
    if out:
        top = max(out, key=lambda k: out[k])
        out[top] = float(aqi)
    return out


_POLLUTANT_CN = {
    "pm25": "PM2.5", "pm10": "PM10", "so2": "SO₂", "no2": "NO₂",
    "o3": "O₃", "co": "CO",
}


def pollutant_label(key):
    if not key:
        return "—"
    return _POLLUTANT_CN.get(key.lower(), key)


def aqi_level(aqi):
    if aqi is None:
        return "—"
    if aqi <= 50:
        return "优"
    if aqi <= 100:
        return "良"
    if aqi <= 150:
        return "轻度污染"
    if aqi <= 200:
        return "中度污染"
    if aqi <= 300:
        return "重度污染"
    return "严重污染"


def aqi_color(aqi):
    if aqi is None:
        return "#9E9E9E"
    if aqi <= 50:
        return "#52AC60"
    if aqi <= 100:
        return "#D6C93B"
    if aqi <= 150:
        return "#E68A2E"
    if aqi <= 200:
        return "#D94B40"
    if aqi <= 300:
        return "#A740A0"
    return "#7A0021"


def rank_change_color(delta):
    if delta is None or delta == 0:
        return "#757575"
    return "#D94B40" if delta > 0 else "#2E8B57"
