# -*- coding: utf-8 -*-
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.spinner import Spinner
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse, Line
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.properties import StringProperty, BooleanProperty, ListProperty, NumericProperty

from aqi168.i18n import tr
from aqi168.aqi import aqi_level, aqi_color, pollutant_label, rank_change_color


class MDCard(BoxLayout):
    """轻量卡片容器，带圆角和背景色。"""
    def __init__(self, bg_color=None, radius=None, **kwargs):
        super().__init__(**kwargs)
        self.radius = radius or dp(10)
        with self.canvas.before:
            self._bg_color = Color(rgba=bg_color or (1, 1, 1, 1))
            self._bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])
        self.bind(pos=self._update_bg, size=self._update_bg)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size


class RankScreen(BoxLayout):
    status_text = StringProperty("")
    source_text = StringProperty("")

    def __init__(self, app_ref=None, on_city_select=None, on_refresh=None,
                 on_settings=None, on_toggle_auto=None, **kwargs):
        super().__init__(orientation="vertical", spacing=0, **kwargs)
        self.app_ref = app_ref
        self._on_city_select = on_city_select
        self._on_refresh = on_refresh
        self._on_settings = on_settings
        self._on_toggle_auto = on_toggle_auto
        self._all_items = []
        self._prev_ranks = {}
        self._auto = True
        self._region = "ALL"
        self._sort = "aqi"
        self._spinner = None
        self._build_ui()

    def _build_ui(self):
        self.add_widget(self._build_top_bar())
        self.add_widget(self._build_filter_bar())
        self.add_widget(self._build_status_bar())
        self.add_widget(self._build_list())
        self.add_widget(self._build_bottom_bar())

    def _build_top_bar(self):
        bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(60),
                        padding=[dp(12), dp(10), dp(8), dp(6)])
        bar.canvas.before.clear()
        with bar.canvas.before:
            Color(0.11, 0.42, 0.42, 1)
            self._top_bg = Rectangle(pos=bar.pos, size=bar.size)
        bar.bind(pos=lambda i, v: setattr(self._top_bg, "pos", v),
                 size=lambda i, v: setattr(self._top_bg, "size", v))

        self._title_lbl = Label(text=tr("app_title"), color=(1, 1, 1, 1),
                                font_size=dp(18), bold=True, size_hint_x=0.5,
                                halign="left", valign="middle")
        self._title_lbl.bind(size=self._title_lbl.setter("text_size"))
        bar.add_widget(self._title_lbl)
        bar.add_widget(Widget())

        self._refresh_btn = Button(text="↻", font_size=dp(22), size_hint_x=None,
                                   width=dp(48), background_color=(1, 1, 1, 0.15),
                                   on_release=lambda x: self._refresh())
        bar.add_widget(self._refresh_btn)

        settings_btn = Button(text="⚙", font_size=dp(22), size_hint_x=None,
                              width=dp(48), background_color=(1, 1, 1, 0.15),
                              on_release=lambda x: self._settings())
        bar.add_widget(settings_btn)
        return bar

    def _build_filter_bar(self):
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        height=dp(104), padding=[dp(10), dp(4)], spacing=dp(4))

        # 搜索框
        self._search = TextInput(hint_text=tr("search_hint"), size_hint_y=None,
                                 height=dp(36), multiline=False,
                                 background_color=(0.96, 0.98, 0.98, 1),
                                 foreground_color=(0.2, 0.2, 0.2, 1),
                                 cursor_color=(0.11, 0.42, 0.42, 1))
        self._search.bind(text=lambda i, v: self._apply_filter())
        box.add_widget(self._search)

        # 区域筛选
        row = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(30))
        row.add_widget(Label(text="区域", size_hint_x=None, width=dp(36),
                             font_size=dp(12), color=(0.4, 0.4, 0.4, 1)))
        self._region_spinner = Spinner(text="全部", size_hint_x=0.4, size_hint_y=None,
                                       height=dp(28), font_size=dp(12),
                                       background_color=(0.11, 0.42, 0.42, 0.15))
        self._region_spinner.values = ["全部", "京津冀及周边", "长三角", "汾渭平原",
                                       "成渝地区", "长江中游城市群", "珠三角", "其他重点城市"]
        self._region_spinner.bind(text=self._on_region_change)
        row.add_widget(self._region_spinner)

        row.add_widget(Label(text="  排序", size_hint_x=None, width=dp(40),
                             font_size=dp(12), color=(0.4, 0.4, 0.4, 1)))
        self._sort_spinner = Spinner(text="AQI排名", size_hint_x=0.4, size_hint_y=None,
                                     height=dp(28), font_size=dp(12),
                                     background_color=(0.11, 0.42, 0.42, 0.15))
        self._sort_spinner.values = ["AQI排名", "PM2.5", "升降位"]
        self._sort_spinner.bind(text=self._on_sort_change)
        row.add_widget(self._sort_spinner)
        box.add_widget(row)
        return box

    def _build_status_bar(self):
        bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(30),
                        padding=[dp(14), 0, dp(12), 0])
        self._status = Label(text="", font_size=dp(11), color=(0.5, 0.5, 0.5, 1),
                             halign="left")
        self._status.bind(size=self._status.setter("text_size"))
        self._source_lbl = Label(text="", font_size=dp(11), color=(0.5, 0.5, 0.5, 1),
                                 halign="right")
        self._source_lbl.bind(size=self._source_lbl.setter("text_size"))
        bar.add_widget(self._status)
        bar.add_widget(self._source_lbl)
        return bar

    def _build_list(self):
        self._scroll = ScrollView()
        self._list_box = BoxLayout(orientation="vertical", size_hint_y=None,
                                   padding=[dp(8), dp(4)], spacing=dp(4))
        self._list_box.bind(minimum_height=self._list_box.setter("height"))
        self._scroll.add_widget(self._list_box)
        return self._scroll

    def _build_bottom_bar(self):
        bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40),
                        padding=[dp(12), dp(4)])
        self._auto_btn = Button(text="⏸ 暂停刷新", size_hint_x=0.4, font_size=dp(12),
                                background_color=(0.11, 0.42, 0.42, 0.15),
                                color=(0.2, 0.3, 0.3, 1),
                                on_release=self._toggle_autorefresh)
        bar.add_widget(self._auto_btn)
        bar.add_widget(Widget())
        self._count_lbl = Label(text="", font_size=dp(11), color=(0.5, 0.5, 0.5, 1))
        bar.add_widget(self._count_lbl)
        return bar

    # ---------- 交互 ----------
    def _refresh(self):
        if self._on_refresh:
            self._on_refresh(show_loading=True)

    def _settings(self):
        if self._on_settings:
            self._on_settings()

    def _toggle_autorefresh(self, *args):
        self._auto = not self._auto
        self._auto_btn.text = "▶ 恢复刷新" if not self._auto else "⏸ 暂停刷新"
        if self._on_toggle_auto:
            self._on_toggle_auto(self._auto)

    def _on_region_change(self, spinner, text):
        self._region = "ALL" if text == "全部" else text
        self._apply_filter()

    def _on_sort_change(self, spinner, text):
        self._sort = {"AQI排名": "aqi", "PM2.5": "pm25", "升降位": "change"}[text]
        self._apply_filter()

    # ---------- 数据呈现 ----------
    def set_loading(self, loading):
        if loading:
            self._refresh_btn.text = "⋯"
            self._refresh_btn.disabled = True
        else:
            self._refresh_btn.text = "↻"
            self._refresh_btn.disabled = False

    def set_status(self, text):
        self.status_text = text
        self._status.text = text

    def set_source(self, text):
        self.source_text = text
        self._source_lbl.text = text

    def show_ranking(self, items, prev):
        self._all_items = items
        self._prev_ranks = {c.id: c.rank for c in prev.values() if c.rank}
        self._count_lbl.text = "共 %d 城" % len(items)
        self._render()

    def _apply_filter(self):
        kw = (self._search.text or "").strip()
        kw = kw.replace("市", "")
        region = self._region
        out = self._all_items
        if region != "ALL":
            out = [c for c in out if c.region == region]
        if kw:
            out = [c for c in out if kw in c.name.replace("市", "") or kw in c.province]
        if self._sort == "pm25":
            out = sorted(out, key=lambda c: (c.pm25 if c.pm25 is not None else 1e9, c.id))
        elif self._sort == "change":
            out = sorted(out, key=lambda c: (abs(self._change(c)) or 9999, c.aqi, c.id))
        else:
            out = sorted(out, key=lambda c: (c.aqi if c.aqi is not None else 1e9, c.id))
        self._render(out)

    def _change(self, city):
        old = self._prev_ranks.get(city.id)
        if not old or not city.rank:
            return 0
        return old - city.rank

    def _render(self, items=None):
        items = items if items is not None else self._all_items
        self._list_box.clear_widgets()
        if not items:
            lbl = Label(text=tr("no_result"), halign="center", color=(0.6, 0.6, 0.6, 1),
                        size_hint_y=None, height=dp(100))
            self._list_box.add_widget(lbl)
            return
        for c in items:
            self._list_box.add_widget(self._row(c))

    def _row(self, city):
        card = MDCard(orientation="vertical", size_hint_y=None, height=dp(64),
                      padding=[dp(10), dp(4)], spacing=dp(2),
                      bg_color=_hex_rgba(aqi_color(city.aqi), 0.10), radius=dp(8))
        card.spacing = dp(0)

        # 第一行
        row = BoxLayout(orientation="horizontal", spacing=dp(6), size_hint_y=0.62)

        # 排名
        rank_lbl = Label(text="%d" % city.rank, size_hint_x=None, width=dp(36),
                         font_size=dp(16), bold=True, color=(0.3, 0.3, 0.3, 1),
                         halign="center")
        row.add_widget(rank_lbl)

        # 城市信息
        info = BoxLayout(orientation="vertical", size_hint_x=0.38)
        info.add_widget(Label(text=city.name, font_size=dp(15), bold=True,
                              color=(0.15, 0.15, 0.15, 1), halign="left"))
        info.add_widget(Label(text="%s · %s" % (city.province, city.region),
                              font_size=dp(9), color=(0.5, 0.5, 0.5, 1),
                              halign="left"))
        row.add_widget(info)

        # AQI 值
        aqi_val = int(city.aqi) if city.aqi is not None else 0
        aqi_lbl = Label(text=str(aqi_val), size_hint_x=0.22, font_size=dp(20), bold=True,
                        color=_hex_rgba(aqi_color(city.aqi)), halign="center")
        row.add_widget(aqi_lbl)

        # 等级标签
        lv = aqi_level(city.aqi)
        lv_lbl = Label(text=lv, size_hint_x=0.2, font_size=dp(11), bold=True,
                       color=(1, 1, 1, 1), halign="center")
        lv_card = MDCard(size_hint_x=0.2, height=dp(24), radius=dp(4),
                         bg_color=_hex_rgba(aqi_color(city.aqi)))
        lv_card.add_widget(lv_lbl)
        row.add_widget(lv_card)

        # 升降
        delta = self._change(city)
        if delta > 0:
            arrow = "▲%d" % delta
        elif delta < 0:
            arrow = "▼%d" % (-delta)
        else:
            arrow = "—"
        ch = Label(text=arrow, size_hint_x=0.14, font_size=dp(11), bold=True,
                   color=rank_change_color(delta), halign="right")
        row.add_widget(ch)

        card.add_widget(row)

        # 第二行：污染物
        sub = BoxLayout(orientation="horizontal", size_hint_y=0.38)
        sub.add_widget(Label(text="首要: %s" % city.primary, font_size=dp(9),
                            color=(0.4, 0.4, 0.4, 1), size_hint_x=0.32, halign="left"))
        sub.add_widget(Label(
            text="PM2.5 %s  PM10 %s  O₃ %s" % (_fmt(city.pm25), _fmt(city.pm10), _fmt(city.o3)),
            font_size=dp(9), color=(0.55, 0.55, 0.55, 1), halign="left"))
        card.add_widget(sub)

        # 点击进入详情
        card.bind(on_touch_down=lambda inst, touch, cid=city.id:
                  self._on_touch(inst, touch, cid))
        return card

    def _on_touch(self, inst, touch, city_id):
        if inst.collide_point(*touch.pos) and touch.is_double_tap or \
           (inst.collide_point(*touch.pos) and touch.time_end - touch.time_start < 0.3):
            if self._on_city_select:
                self._on_city_select(city_id)
            return True
        return False


def _fmt(v):
    return "%.0f" % v if isinstance(v, (int, float)) else "—"


def _hex_rgba(h, a=1.0):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    return (r, g, b, a)
