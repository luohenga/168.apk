# -*- coding: utf-8 -*-
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.slider import Slider
from kivy.graphics import Color, Rectangle, RoundedRectangle

from aqi168.i18n import tr


class MDCard(BoxLayout):
    def __init__(self, bg_color=None, radius=None, **kwargs):
        super().__init__(**kwargs)
        self.radius = radius or dp(10)
        with self.canvas.before:
            self._bg_color = Color(rgba=bg_color or (1, 1, 1, 1))
            self._bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])
        self.bind(pos=self._update_bg, size=self._update_bg)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size


class SettingsScreen(BoxLayout):
    def __init__(self, app_ref=None, on_back=None, on_source_change=None,
                 on_interval_change=None, **kwargs):
        super().__init__(orientation="vertical", **kwargs)
        self.app_ref = app_ref
        self._on_back = on_back
        self._on_source_change = on_source_change
        self._on_interval_change = on_interval_change
        self._current_source = "cnemc"
        self._current_interval = 10
        self._build_ui()

    def _build_ui(self):
        # 顶栏
        bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56),
                        padding=[dp(8), dp(8)])
        with bar.canvas.before:
            Color(0.11, 0.42, 0.42, 1)
            self._bar_bg = Rectangle(pos=bar.pos, size=bar.size)
        bar.bind(pos=lambda i, v: setattr(self._bar_bg, "pos", v),
                 size=lambda i, v: setattr(self._bar_bg, "size", v))

        back_btn = Button(text="←", font_size=dp(20), size_hint_x=None, width=dp(48),
                          background_color=(1, 1, 1, 0.15), color=(1, 1, 1, 1),
                          on_release=self._back)
        bar.add_widget(back_btn)
        bar.add_widget(Label(text=tr("settings"), color=(1, 1, 1, 1),
                             font_size=dp(18), bold=True))
        bar.add_widget(Widget(size_hint_x=None, width=dp(48)))
        self.add_widget(bar)

        # 内容
        self._scroll = ScrollView()
        self._body = BoxLayout(orientation="vertical", size_hint_y=None,
                              padding=[dp(12), dp(8)], spacing=dp(12))
        self._body.bind(minimum_height=self._body.setter("height"))
        self._scroll.add_widget(self._body)
        self.add_widget(self._scroll)

    def _back(self, *args):
        if self._on_back:
            self._on_back()

    def refresh(self, data_manager):
        self._body.clear_widgets()
        self._current_source = data_manager.current_source_key()
        self._current_interval = data_manager.refresh_interval_min
        self._render_source(data_manager)
        self._render_interval()
        self._render_token(data_manager)
        self._render_caveat()
        self._render_about()

    def _render_source(self, dm):
        card = MDCard(orientation="vertical", size_hint_y=None, padding=[dp(14), dp(10)],
                      radius=dp(10), bg_color=(1, 1, 1, 1))
        card.add_widget(Label(text=tr("select_source"), font_size=dp(14), bold=True,
                              color=(0.2, 0.2, 0.2, 1), halign="left",
                              size_hint_y=None, height=dp(28)))

        sources = dm.available_sources()
        card.height = dp(28 + 40 * len(sources) + 20)
        for key, label in sources:
            row = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(36),
                            spacing=dp(8))
            sel = "●" if key == self._current_source else "○"
            col = (0.11, 0.42, 0.42, 1) if key == self._current_source else (0.6, 0.6, 0.6, 1)
            row.add_widget(Label(text="%s  %s" % (sel, label), font_size=dp(12),
                                 color=col, halign="left"))
            btn = Button(text="选择", size_hint_x=None, width=dp(56), font_size=dp(11),
                         background_color=(0.11, 0.42, 0.42, 0.15)
                         if key == self._current_source else (0.9, 0.9, 0.9, 1),
                         color=(0.11, 0.42, 0.42, 1) if key == self._current_source else (0.5, 0.5, 0.5, 1),
                         disabled=(key == self._current_source))
            btn.bind(on_release=lambda b, k=key: self._pick_source(k))
            row.add_widget(btn)
            card.add_widget(row)
        self._body.add_widget(card)

    def _render_interval(self):
        card = MDCard(orientation="vertical", size_hint_y=None, height=dp(80),
                      padding=[dp(14), dp(10)], radius=dp(10), bg_color=(1, 1, 1, 1))
        self._interval_lbl = Label(
            text="%s：%d %s" % (tr("refresh_interval"), self._current_interval, tr("minutes")),
            font_size=dp(13), bold=True, color=(0.2, 0.2, 0.2, 1), halign="left",
            size_hint_y=None, height=dp(26))
        card.add_widget(self._interval_lbl)
        self._slider = Slider(min=1, max=60, value=self._current_interval,
                              size_hint_y=None, height=dp(40),
                              background_color=(0.11, 0.42, 0.42, 0.3),
                              value_track=True,
                              value_track_color=(0.11, 0.42, 0.42, 0.8))
        self._slider.bind(value=self._on_slider)
        card.add_widget(self._slider)
        self._body.add_widget(card)

    def _render_token(self):
        card = MDCard(orientation="vertical", size_hint_y=None, height=dp(90),
                      padding=[dp(14), dp(10)], radius=dp(10), bg_color=(1, 1, 1, 1))
        card.add_widget(Label(text="WAQI Token（公开源）", font_size=dp(13), bold=True,
                              color=(0.2, 0.2, 0.2, 1), halign="left",
                              size_hint_y=None, height=dp(24)))
        card.add_widget(Label(text="从 api.waqi.info 免费申请，填入后可用公开聚合源",
                              font_size=dp(10), color=(0.5, 0.5, 0.5, 1), halign="left",
                              size_hint_y=None, height=dp(18)))
        self._token_field = TextInput(hint_text="demo-token", password=True,
                                      size_hint_y=None, height=dp(36),
                                      multiline=False)
        card.add_widget(self._token_field)
        self._body.add_widget(card)

    def _render_caveat(self):
        card = MDCard(orientation="vertical", size_hint_y=None, padding=[dp(14), dp(10)],
                      radius=dp(10), bg_color=(0.98, 0.97, 0.92, 1))
        card.add_widget(Label(text=tr("note_caveat"), font_size=dp(12), bold=True,
                              color=(0.3, 0.3, 0.3, 1), halign="left",
                              size_hint_y=None, height=dp(20)))
        card.add_widget(Label(text=tr("note_official"), font_size=dp(10),
                              color=(0.5, 0.5, 0.5, 1), halign="left",
                              text_size=(dp(300), None), size_hint_y=None, height=dp(36)))
        card.add_widget(Label(text=tr("caveat_text"), font_size=dp(10),
                              color=(0.5, 0.5, 0.5, 1), halign="left",
                              text_size=(dp(300), None), size_hint_y=None, height=dp(20)))
        self._body.add_widget(card)

    def _render_about(self):
        card = MDCard(orientation="vertical", size_hint_y=None, padding=[dp(14), dp(10)],
                      radius=dp(10), bg_color=(0.96, 0.98, 0.98, 1))
        card.add_widget(Label(text=tr("detail_about_text"), font_size=dp(10),
                              color=(0.5, 0.5, 0.5, 1), halign="left",
                              text_size=(dp(300), None), size_hint_y=None, height=dp(60)))
        self._body.add_widget(card)

    def _pick_source(self, key):
        self._current_source = key
        if self._on_source_change:
            self._on_source_change(key)
        if self.app_ref and hasattr(self.app_ref, "data_manager"):
            self.refresh(self.app_ref.data_manager)

    def _on_slider(self, inst, val):
        v = int(round(val))
        self._interval_lbl.text = "%s：%d %s" % (tr("refresh_interval"), v, tr("minutes"))
        if v != self._current_interval:
            self._current_interval = v
            if self._on_interval_change:
                self._on_interval_change(v)
