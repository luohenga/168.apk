# -*- coding: utf-8 -*-
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse, Line
from kivy.properties import ListProperty

from aqi168.i18n import tr
from aqi168.aqi import aqi_level, aqi_color, pollutant_label


class MDCard(BoxLayout):
    def __init__(self, bg_color=None, radius=None, **kwargs):
        super().__init__(**kwargs)
        self.radius = radius or dp(10)
        with self.canvas.before:
            self._bg_color = Color(rgba=bg_color or (1, 1, 1, 1))
            self._bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])
        self.bind(pos=self._update_bg, size=self._update_bg)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size


class DetailScreen(BoxLayout):
    def __init__(self, app_ref=None, on_back=None, **kwargs):
        super().__init__(orientation="vertical", **kwargs)
        self.app_ref = app_ref
        self._on_back = on_back
        self.city_id = None
        self._store = None
        self._manager = None
        self._build_ui()

    def _build_ui(self):
        # 顶栏
        bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56),
                        padding=[dp(8), dp(8)])
        with bar.canvas.before:
            Color(0.11, 0.42, 0.42, 1)
            self._bar_bg = Rectangle(pos=bar.pos, size=bar.size)
        bar.bind(pos=lambda i, v: setattr(self._bar_bg, "pos", v),
                 size=lambda i, v: setattr(self._bar_bg, "size", v))

        back_btn = Button(text="←", font_size=dp(20), size_hint_x=None, width=dp(48),
                          background_color=(1, 1, 1, 0.15), color=(1, 1, 1, 1),
                          on_release=self._back)
        bar.add_widget(back_btn)

        self._title = Label(text="", color=(1, 1, 1, 1), font_size=dp(18), bold=True,
                            halign="left", valign="middle")
        self._title.bind(size=self._title.setter("text_size"))
        bar.add_widget(self._title)

        bar.add_widget(Widget(size_hint_x=None, width=dp(48)))
        self.add_widget(bar)

        # 内容区
        self._scroll = ScrollView()
        self._body = BoxLayout(orientation="vertical", size_hint_y=None,
                              padding=[dp(12), dp(8)], spacing=dp(10))
        self._body.bind(minimum_height=self._body.setter("height"))
        self._scroll.add_widget(self._body)
        self.add_widget(self._scroll)

    def _back(self, *args):
        if self._on_back:
            self._on_back()

    def bind_city(self, city_id, city_store, data_manager):
        self.city_id = city_id
        self._store = city_store
        self._manager = data_manager
        city = city_store.get(city_id)
        if city:
            self._title.text = "%s · %s" % (city.name, city.province)

    def update_chart(self, city_store, data_manager):
        self._store = city_store
        self._manager = data_manager
        self._body.clear_widgets()
        city = self._store.get(self.city_id)
        if not city:
            self._body.add_widget(Label(text="城市数据暂不可用", color=(0.5, 0.5, 0.5, 1),
                                        size_hint_y=None, height=dp(100)))
            return
        self._render_header(city)
        self._render_pollutants(city)
        self._render_trend(city)
        self._render_note(city)

    def _render_header(self, city):
        card = MDCard(orientation="vertical", size_hint_y=None, height=dp(140),
                      padding=[dp(16), dp(12)], radius=dp(12),
                      bg_color=(1, 1, 1, 1))
        row = BoxLayout(orientation="horizontal", spacing=dp(12))

        # 左：AQI大数字
        aqi_box = BoxLayout(orientation="vertical", size_hint_x=0.4)
        col = _hex_rgba(aqi_color(city.aqi))
        aqi_box.add_widget(Label(text=str(int(city.aqi)) if city.aqi else "—",
                                 font_size=dp(42), bold=True, color=col,
                                 halign="center"))
        aqi_box.add_widget(Label(text=aqi_level(city.aqi), font_size=dp(16), bold=True,
                                 color=col, halign="center"))
        row.add_widget(aqi_box)

        # 右：信息
        info = BoxLayout(orientation="vertical", spacing=dp(2), size_hint_x=0.6)
        info.add_widget(self._kv("排名", "#%d / 168" % city.rank if city.rank else "—"))
        info.add_widget(self._kv("首要污染物", city.primary))
        info.add_widget(self._kv("更新时间", city.station_time or "—"))
        info.add_widget(self._kv("所属区域", city.region))
        info.add_widget(self._kv("省份", city.province))
        row.add_widget(info)
        card.add_widget(row)
        self._body.add_widget(card)

    def _render_pollutants(self, city):
        lbl = Label(text=tr("pollutants"), font_size=dp(14), bold=True,
                    color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=dp(28),
                    halign="left")
        lbl.bind(size=lbl.setter("text_size"))
        self._body.add_widget(lbl)

        items = [
            ("PM2.5", city.pm25, "μg/m³", 75),
            ("PM10", city.pm10, "μg/m³", 150),
            ("SO₂", city.so2, "μg/m³", 50),
            ("NO₂", city.no2, "μg/m³", 40),
            ("O₃", city.o3, "μg/m³", 160),
            ("CO", city.co, "mg/m³", 4),
        ]
        for label, val, unit, ref in items:
            card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(40),
                          padding=[dp(12), dp(4)], spacing=dp(8), radius=dp(6),
                          bg_color=(1, 1, 1, 1))
            card.add_widget(Label(text=label, size_hint_x=0.18, font_size=dp(12),
                                  bold=True, color=(0.2, 0.2, 0.2, 1)))
            card.add_widget(Label(
                text="%.1f %s" % (val, unit) if val is not None else "—",
                size_hint_x=0.28, font_size=dp(12), color=(0.3, 0.3, 0.3, 1)))
            # 浓度条
            bar_wrap = ConcentrationBar(value=val, ref=ref,
                                       color=_hex_rgba(aqi_color(min(300, (val or 0) * 3))))
            bar_wrap.size_hint_x = 0.44
            bar_wrap.size_hint_y = None
            bar_wrap.height = dp(8)
            card.add_widget(bar_wrap)
            self._body.add_widget(card)

    def _render_trend(self, city):
        lbl = Label(text=tr("trend_title"), font_size=dp(14), bold=True,
                    color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=dp(28),
                    halign="left")
        lbl.bind(size=lbl.setter("text_size"))
        self._body.add_widget(lbl)

        if len(city.history) < 2:
            self._body.add_widget(Label(
                text="趋势数据采集中，等待更多时次…", color=(0.6, 0.6, 0.6, 1),
                size_hint_y=None, height=dp(60)))
            return

        chart = TrendChart(history=city.history, color=_hex_rgba(aqi_color(city.aqi)))
        chart.size_hint_y = None
        chart.height = dp(180)
        self._body.add_widget(chart)

    def _render_note(self, city):
        card = MDCard(orientation="vertical", size_hint_y=None, padding=[dp(12), dp(8)],
                      radius=dp(8), bg_color=(0.98, 0.97, 0.92, 1))
        card.add_widget(Label(text=tr("detail_about"), font_size=dp(12), bold=True,
                              color=(0.3, 0.3, 0.3, 1), halign="left",
                              size_hint_y=None, height=dp(20)))
        card.add_widget(Label(text=tr("detail_about_text"), font_size=dp(10),
                              color=(0.5, 0.5, 0.5, 1), halign="left",
                              text_size=(dp(300), None), size_hint_y=None,
                              height=dp(60)))
        card.add_widget(Label(text=tr("caveat_text"), font_size=dp(10),
                              color=(0.5, 0.5, 0.5, 1), halign="left",
                              text_size=(dp(300), None), size_hint_y=None,
                              height=dp(20)))
        self._body.add_widget(card)

    def _kv(self, k, v):
        box = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(22))
        box.add_widget(Label(text=k + "：", size_hint_x=0.3, font_size=dp(11),
                             color=(0.5, 0.5, 0.5, 1)))
        box.add_widget(Label(text=str(v), size_hint_x=0.7, font_size=dp(11), bold=True,
                             color=(0.2, 0.2, 0.2, 1)))
        return box


class ConcentrationBar(Widget):
    """水平浓度条。"""
    def __init__(self, value=None, ref=100, color=(0.3, 0.7, 0.3, 1), **kwargs):
        super().__init__(**kwargs)
        self.value = value
        self.ref = ref
        self.color = color
        self.bind(pos=self._redraw, size=self._redraw)

    def _redraw(self, *args):
        self.canvas.clear()
        if self.value is None:
            return
        with self.canvas:
            Color(0.9, 0.9, 0.9, 1)
            Rectangle(pos=self.pos, size=self.size)
            Color(*self.color)
            frac = min(1.0, self.value / self.ref)
            Rectangle(pos=self.pos, size=(self.width * frac, self.height))


class TrendChart(Widget):
    """24 时次趋势折线图。"""
    def __init__(self, history=None, color=(0.8, 0.3, 0.2, 1), **kwargs):
        super().__init__(**kwargs)
        self.history = history or []
        self.color = color
        self.bind(pos=self._redraw, size=self._redraw)

    def _redraw(self, *args):
        self.canvas.clear()
        if len(self.history) < 2:
            return
        pts = self.history[-24:]
        pad_l, pad_r, pad_t, pad_b = dp(36), dp(8), dp(14), dp(20)
        w, h = self.width - pad_l - pad_r, self.height - pad_t - pad_b
        if w <= 0 or h <= 0:
            return

        vals = [v for _, v in pts]
        lo = min(vals)
        hi = max(vals)
        span = (hi - lo) or 1
        lo -= span * 0.15
        hi += span * 0.15
        span = hi - lo

        def px(i, v):
            return (pad_l + w * i / (len(pts) - 1),
                    pad_b + h * (v - lo) / span)

        with self.canvas:
            # 网格
            Color(0.9, 0.9, 0.9, 1)
            for i in range(1, 4):
                y = pad_b + h * i / 4
                Line(points=[pad_l, y, self.width - pad_r, y], width=0.5)

            # Y轴标签
            # 折线
            line_pts = []
            for i in range(len(pts)):
                line_pts.extend(px(i, pts[i][1]))

            Color(*self.color)
            Line(points=line_pts, width=2.0, cap="round", joint="round")

            # 端点圆
            step = max(1, len(pts) // 6)
            for i in range(0, len(pts), step):
                x, y = px(i, pts[i][1])
                Color(1, 1, 1, 1)
                Ellipse(pos=(x - dp(3), y - dp(3)), size=(dp(6), dp(6)))
                Color(*self.color)
                Ellipse(pos=(x - dp(1.5), y - dp(1.5)), size=(dp(3), dp(3)))

        # 轴标签用 Label
        self._draw_labels(pts, lo, hi)

    def _draw_labels(self, pts, lo, hi):
        for child in list(self.children):
            if isinstance(child, Label):
                self.remove_widget(child)
        # Y 轴值标签
        for i in range(5):
            v = lo + (hi - lo) * i / 4
            x = dp(2)
            y = dp(20) + (self.height - dp(34) - dp(20)) * i / 4
            lbl = Label(text="%d" % v, pos=(x, y), size=(dp(30), dp(16)),
                        font_size=dp(8), color=(0.5, 0.5, 0.5, 1), halign="left")
            self.add_widget(lbl)


def _hex_rgba(h, a=1.0):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    return (r, g, b, a)
