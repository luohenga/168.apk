# -*- coding: utf-8 -*-
"""168 重点城市空气质量实时排名 App 启动入口"""
import os
os.environ.setdefault("KIVY_NO_ARGS", "1")
os.environ.setdefault("KIVY_NO_CONSOLELOG", "1")

from aqi168.app import AQI168App

if __name__ == "__main__":
    AQI168App().run()
